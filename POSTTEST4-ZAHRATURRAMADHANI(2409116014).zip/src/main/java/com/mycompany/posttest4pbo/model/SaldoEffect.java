// Post Test 4 PBO
// Nama: Zahraturramadhani
// NIM: 2409116014
// Kelas: A'2024 Sistem Informasi

package com.mycompany.posttest4pbo.model;

// Interface: kontrak efek transaksi terhadap saldo
public interface SaldoEffect {
    //Nilai bertanda: pemasukan (+), pengeluaran (−)
    double efekSaldo();
}

