// Post Test 4 PBO
// Nama: Zahraturramadhani
// NIM: 2409116014
// Kelas: A'2024 Sistem Informasi

package com.mycompany.posttest4pbo.model;

public class Pemasukan extends Transaksi {
    public Pemasukan(int id, String tanggal, String keterangan,
                     String kategori, String metodePembayaran, double jumlah) {
        super(id, tanggal, keterangan, "Pemasukan", kategori, metodePembayaran, jumlah);
    }

    // Overriding: kunci jenis agar konsisten
    @Override
    public String getJenis() { return "Pemasukan"; }

    @Override
    public void setJenis(String jenis) {}

    // Overriding abstract method
    @Override
    protected int tandaSaldo() { return +1; }
}

