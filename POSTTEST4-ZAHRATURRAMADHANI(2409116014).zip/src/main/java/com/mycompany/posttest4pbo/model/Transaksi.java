// Post Test 4 PBO
// Nama: Zahraturramadhani
// NIM: 2409116014
// Kelas: A'2024 Sistem Informasi

package com.mycompany.posttest4pbo.model;

public abstract class Transaksi implements SaldoEffect {
    private int id;
    private String tanggal;
    private String keterangan;
    private String jenis;              
    private String kategori;
    private String metodePembayaran;
    private double jumlah;

    protected Transaksi(int id, String tanggal, String keterangan, String jenis,
                        String kategori, String metodePembayaran, double jumlah) {
        this.id = id;
        this.tanggal = tanggal;
        this.keterangan = keterangan;
        this.jenis = jenis;
        this.kategori = kategori;
        this.metodePembayaran = metodePembayaran;
        this.jumlah = jumlah;
    }

    // Abstraction: +1 untuk pemasukan, −1 untuk pengeluaran
    protected abstract int tandaSaldo();

    // Implementasi interface via template di induk
    @Override
    public double efekSaldo() {
        return tandaSaldo() * jumlah;
    }

    // Encapsulation (getter/setter)
    public int getId() { return id; }
    public String getTanggal() { return tanggal; }
    public String getKeterangan() { return keterangan; }
    public String getJenis() { return jenis; }
    public String getKategori() { return kategori; }
    public String getMetodePembayaran() { return metodePembayaran; }
    public double getJumlah() { return jumlah; }

    public void setTanggal(String tanggal) { this.tanggal = tanggal; }
    public void setKeterangan(String keterangan) { this.keterangan = keterangan; }
    public void setJenis(String jenis) { this.jenis = jenis; } // tetap ada utk kompatibilitas
    public void setKategori(String kategori) { this.kategori = kategori; }
    public void setMetodePembayaran(String metodePembayaran) { this.metodePembayaran = metodePembayaran; }
    public void setJumlah(double jumlah) { this.jumlah = jumlah; }
}

